This is your group repo for your final project for COGS108.

This repository is private, and is only visible to the course instructors and your group mates; it is not visible to anyone else.

This repository will be frozen on the due date: 11:59pm on Tuesday, June 13th. No further changes can be made after that time.

Your final project will be graded based solely on a project notebook.

Make sure you have a notebook called 'FinalProject.ipynb' present in this repository by the due date.
